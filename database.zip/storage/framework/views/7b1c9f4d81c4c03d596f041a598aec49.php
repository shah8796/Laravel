<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="X-CSRF-TOKEN" content="<?php echo e(csrf_token()); ?>">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <title>Document</title>
</head>
<body >
    
    
    
    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('books', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
    
</body>

</html>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Get the form and bookview element
        const form = document.getElementById('frm');
        const bookview = document.getElementById('bookview');
    
        // Add event listener to the form submission
        form.addEventListener('submit', function (e) {
            e.preventDefault(); // Prevent default form submission
    
            // Get the search input value
            const searchData = document.getElementById('search').value;
    
            // Send AJAX request
            $.ajax({
                type: 'POST',
                data: {
                    'search': searchData,
                    "_token": "<?php echo e(csrf_token()); ?>"
                },
                url: '<?php echo e(route('searchview')); ?>',
                success: function (response) {
                    // Update the bookview element with the response
                    bookview.innerHTML = response;
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText); // Log any errors
                }
            });
        });
    });
    </script><?php /**PATH /mnt/d/Laravel/book-app/resources/views/welcome.blade.php ENDPATH**/ ?>