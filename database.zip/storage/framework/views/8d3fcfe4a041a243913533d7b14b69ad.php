<div id="bookview" class="grid grid-cols-1 md:grid-cols-2 gap-4 lg:grid-cols-3">
    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div id="books" class="max-w-md bg-white p-5 shadow-lg rounded-lg overflow-hidden">
        <img class="w-full h-56 object-fill object-center" src="<?php echo e(asset('images/' . $book->image)); ?>" alt="Image">
        <div class="p-4">
            <h2 class="text-xl font-semibold text-gray-800"><?php echo e($book->title); ?></h2>
            <p class="mt-2 text-gray-600"><?php echo e($book->short_description); ?></p>
            <p class="mt-2 text-gray-600"><?php echo e($book->price); ?></p>
            <div class="mt-4">
                <?php if(auth()->guard()->check()): ?>
                    <a href="#" id="<?php echo e($book->id); ?>" class="readmore text-blue-500 inline-block">Read more</a>
                    <?php
                        $isFavorite = $fav->contains('bookId', $book->id);
                    ?>
                    <?php if($isFavorite): ?>
                        <span id="<?php echo e($book->id); ?>" class="favorite-star text-yellow-500 cursor-pointer ml-2">&#9733;</span>
                    <?php else: ?>
                        <span id="<?php echo e($book->id); ?>" class="favorite-star text-yellow-500 cursor-pointer ml-2">&#9734;</span>
                    <?php endif; ?>
                        
                <?php else: ?>
                    <span class="text-gray-500 inline-block">Please log in to read more</span>
                <?php endif; ?>
            </div>
            <div id="details_<?php echo e($book->id); ?>" class="details hidden mt-4" >
                <p  class="mt-2 text-gray-600"><?php echo e($book->details); ?></p>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<?php /**PATH /mnt/d/Laravel/book-app/resources/views/books.blade.php ENDPATH**/ ?>