<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    

    <div class="py-12 bg-white text-black">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <?php if(auth()->user()->is_admin): ?>
                <a href="<?php echo e(route('admin')); ?>" class="bg-blue-100 m-5 rounded-md p-3">Admin</a>
                
            <?php endif; ?>
            
            
            
        
            <button id="fav" class="bg-blue-100 m-5 rounded-md p-3">
                Favourites
            </button>
            <button id="all" class="bg-blue-100 m-5 rounded-md p-3 ">
                ALL
            </button>
            <form  id="frm">
                <?php echo csrf_field(); ?>
                <div class="flex flex-row justify-between items-center">
                    <input type="text" id="search" name="search" class="w-full h-8" placeholder="Search">
                    <button type="submit" class="h-8  bg-blue-100">search</button>

                </div>
            </form>

        
        <?php echo $__env->make("books", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
            
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
   document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('frm');
        const bookview = document.getElementById('bookview');
    
        // Add event listener to the form submission
        form.addEventListener('submit', function (e) {
            e.preventDefault(); // Prevent default form submission
    
            // Get the search input value
            const searchData = document.getElementById('search').value;
    
            // Send AJAX request
            $.ajax({
                type: 'POST',
                data: {
                    'search': searchData,
                    '_token': $('meta[name="csrf-token"]').attr('content')
                },
                url: '<?php echo e(route('searchview')); ?>',
                success: function (response) {
                    // Update the bookview element with the response
                    bookview.innerHTML = response;
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText); // Log any errors
                }
            });
        });
    // Event delegation for readmore links
    document.addEventListener('click', function (event) {
        if (event.target.classList.contains('readmore')) {
            event.preventDefault();
            const bookId = event.target.getAttribute('id');
            const details = document.getElementById('details_' + bookId);
            details.classList.remove('hidden');
        }
    });
    

    // Event delegation for favorite-star icons
    document.addEventListener('click', function (event) {
        if (event.target.classList.contains('favorite-star')) {
            const bookId = event.target.getAttribute('id');
            let isFavorite = event.target.classList.contains('favorited');
            let updatedIsFavorite = !isFavorite;

            if (isFavorite) {
                event.target.innerHTML = '&#9734;';
                event.target.classList.remove('favorited');
                // Add logic to remove book from favorites
            } else {
                event.target.innerHTML = '&#9733;';
                event.target.classList.add('favorited');
                // Add logic to mark book as favorite
            }

            $.ajax({
                type: 'POST',
                data: {
                    'bookid': bookId,
                    'isFavourite': updatedIsFavorite,
                    '_token': $('meta[name="csrf-token"]').attr('content')
                },
                url: '<?php echo e(route('favourite')); ?>',
                success: function (response) {
                    console.log(response);
                },
                error: function (xhr, status, error) {
                    console.error('Error favoriting book:', error);
                }
            });
        }
    });

    const btn = document.getElementById('fav');
    

    btn.addEventListener('click', function (e) {
        e.preventDefault();
        $.ajax({
            type: 'POST',
            data: {
                '_token': $('meta[name="csrf-token"]').attr('content')
            },
            url: '<?php echo e(route('favouriteview')); ?>',
            success: function (response) {
                bookview.innerHTML = response;
            }
        });
    });
    const btnAll = document.getElementById('all');
    // const bookview = document.getElementById('bookview');

    btnAll.addEventListener('click', function (e) {
        e.preventDefault();
        $.ajax({
            type: 'POST',
            data: {
                '_token': $('meta[name="csrf-token"]').attr('content')
            },
            url: '<?php echo e(route('allview')); ?>',
            success: function (response) {
                bookview.innerHTML = response;
            }
        });
    });
});

</script>

<?php /**PATH /mnt/d/Laravel/book-app/resources/views/dashboard.blade.php ENDPATH**/ ?>